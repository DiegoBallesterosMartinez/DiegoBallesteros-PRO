import java.util.ArrayList;
import java.util.Scanner;

public class Ejercicio1 {
    public static void main(String[] args) {


        Scanner lectorTeclado;
        ArrayList<String> listaProductos = new ArrayList<>();


        Object[][] productos = {{"Bocatas","4.00"},{"Bebida","3.00"}};


    }
}




